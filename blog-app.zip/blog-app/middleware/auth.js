const jwt = require('jsonwebtoken');

function authenticateJWT(req, res, next) {
  const token = req.headers['authorization'];

  if (token) {
    jwt.verify(token, 'secret_key', (err, user) => { // Use your secret key here
      if (err) {
        return res.sendStatus(403); // Forbidden
      }
      req.user = user; // Store the user info for later use
      next();
    });
  } else {
    res.sendStatus(401); // Unauthorized
  }
}

module.exports = { authenticateJWT };
