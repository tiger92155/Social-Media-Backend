const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const authRoutes = require('./routes/auth');
const postRoutes = require('./routes/posts');
const userRoutes = require('./routes/users');
const { authenticateJWT } = require('./middleware/auth');
const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/posts', authenticateJWT, postRoutes);
app.use('/api/users', authenticateJWT, userRoutes);

// Root endpoint
app.get('/', (req, res) => {
  res.send('Welcome to the Blog API');
});

// Start server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
