const express = require('express');
const router = express.Router();
const Post = require('../models/Post');
const { authenticateJWT } = require('../middleware/auth');

// Create a new post
router.post('/', authenticateJWT, (req, res) => {
  const { title, description, isPublic } = req.body;
  const authorEmail = req.user.email;

  const newPost = Post.createPost(title, description, authorEmail, isPublic);
  res.status(201).json({ message: 'Post created successfully', post: newPost });
});

// Get posts (public and private for followers)
router.get('/', (req, res) => {
  const email = req.user ? req.user.email : null; // Check if user is authenticated
  const posts = Post.getPosts(email);
  res.json(posts);
});

// Like a post
router.post('/:id/like', authenticateJWT, (req, res) => {
  const postId = req.params.id;
  const userEmail = req.user.email;

  const likedPost = Post.likePost(postId, userEmail);
  if (likedPost) {
    res.json({ message: 'Post liked successfully', post: likedPost });
  } else {
    res.status(404).json({ message: 'Post not found or already liked' });
  }
});

// Comment on a post
router.post('/:id/comments', authenticateJWT, (req, res) => {
  const postId = req.params.id;
  const userEmail = req.user.email;
  const { commentText } = req.body;

  const postWithComment = Post.commentOnPost(postId, userEmail, commentText);
  if (postWithComment) {
    res.json({ message: 'Comment added successfully', post: postWithComment });
  } else {
    res.status(404).json({ message: 'Post not found' });
  }
});

// Delete a comment
router.delete('/:id/comments/:commentIndex', authenticateJWT, (req, res) => {
  const postId = req.params.id;
  const userEmail = req.user.email;
  const commentIndex = req.params.commentIndex;

  const updatedPost = Post.deleteComment(postId, userEmail, commentIndex);
  if (updatedPost) {
    res.json({ message: 'Comment deleted successfully', post: updatedPost });
  } else {
    res.status(404).json({ message: 'Post or comment not found, or you are not the owner' });
  }
});

module.exports = router;
