const express = require('express');
const router = express.Router();
const User = require('../models/User');
const { authenticateJWT } = require('../middleware/auth');

// Get user profile
router.get('/profile', authenticateJWT, (req, res) => {
  const email = req.user.email;
  const users = User.readFile();
  const user = users.find(u => u.email === email);
  if (user) {
    res.json({ email: user.email, following: user.following });
  } else {
    res.status(404).json({ message: 'User not found' });
  }
});

// Get a specific user by email
router.get('/:email', (req, res) => {
  const email = req.params.email;
  const users = User.readFile();
  const user = users.find(u => u.email === email);
  if (user) {
    res.json({ email: user.email, following: user.following });
  } else {
    res.status(404).json({ message: 'User not found' });
  }
});

module.exports = router;
