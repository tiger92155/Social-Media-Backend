const fs = require('fs');
const path = require('path');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const filePath = path.join(__dirname, '../data/users.json');

class User {
  constructor(email, password) {
    this.email = email;
    this.password = password; // Hashed password
    this.following = []; // List of users this user is following
  }

  static readFile() {
    if (!fs.existsSync(filePath)) {
      return []; // Return an empty array if the file does not exist
    }
    const data = fs.readFileSync(filePath);
    return JSON.parse(data);
  }

  static saveFile(users) {
    fs.writeFileSync(filePath, JSON.stringify(users, null, 2));
  }

  static register(email, password) {
    const users = User.readFile();
    if (users.find(user => user.email === email)) {
      throw new Error('User already exists');
    }
    const hashedPassword = bcrypt.hashSync(password, 10);
    const newUser = new User(email, hashedPassword);
    users.push(newUser);
    User.saveFile(users);
    return newUser;
  }

  static login(email, password) {
    const users = User.readFile();
    const user = users.find(user => user.email === email);
    if (user && bcrypt.compareSync(password, user.password)) {
      const token = jwt.sign({ email: user.email }, 'secret_key'); // Use your secret key here
      return { user, token };
    }
    throw new Error('Invalid credentials');
  }

  static followUser(followerEmail, followingEmail) {
    const users = User.readFile();
    const follower = users.find(user => user.email === followerEmail);
    const following = users.find(user => user.email === followingEmail);
    
    if (follower && following && !follower.following.includes(followingEmail)) {
      follower.following.push(followingEmail);
      User.saveFile(users);
      return follower;
    }
    return null; // If follower or following not found or already following
  }

  static getFollowedUsers(email) {
    const users = User.readFile();
    const user = users.find(user => user.email === email);
    if (user) {
      return user.following;
    }
    return []; // If user not found
  }
}

module.exports = User;
