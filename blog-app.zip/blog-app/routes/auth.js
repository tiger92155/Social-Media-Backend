const express = require('express');
const router = express.Router();
const User = require('../models/User');
const { authenticateJWT } = require('../middleware/auth');

// User Registration
router.post('/register', (req, res) => {
  const { email, password } = req.body;
  try {
    const newUser = User.register(email, password);
    res.status(201).json({ message: 'User registered successfully', user: newUser });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// User Login
router.post('/login', (req, res) => {
  const { email, password } = req.body;
  try {
    const { user, token } = User.login(email, password);
    res.json({ message: 'Login successful', user, token });
  } catch (error) {
    res.status(401).json({ message: error.message });
  }
});

// Follow User
router.post('/follow', authenticateJWT, (req, res) => {
  const { followingEmail } = req.body;
  const followerEmail = req.user.email;

  const updatedFollower = User.followUser(followerEmail, followingEmail);
  if (updatedFollower) {
    res.json({ message: 'Now following', following: updatedFollower.following });
  } else {
    res.status(404).json({ message: 'User not found or already following' });
  }
});

// Get Followed Users
router.get('/following', authenticateJWT, (req, res) => {
  const email = req.user.email;
  const followedUsers = User.getFollowedUsers(email);
  res.json({ following: followedUsers });
});

module.exports = router;
